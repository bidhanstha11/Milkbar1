﻿using MilkBarRetailShop.BLL;

namespace MilkBarRetailShop.DAL
{
    internal class userDALBase
    {

    }
}