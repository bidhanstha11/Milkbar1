﻿namespace MilkBarRetailShop.UI
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            panel1 = new Panel();
            btnLogin = new Button();
            cmbUserType = new ComboBox();
            txtPassword = new TextBox();
            txtUsername = new TextBox();
            lblUserType = new Label();
            lblPassword = new Label();
            lblUsername = new Label();
            lblHeader = new Label();
            pboxClose = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pboxClose).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btnLogin);
            panel1.Controls.Add(cmbUserType);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(txtUsername);
            panel1.Controls.Add(lblUserType);
            panel1.Controls.Add(lblPassword);
            panel1.Controls.Add(lblUsername);
            panel1.Controls.Add(lblHeader);
            panel1.Location = new Point(45, 43);
            panel1.Name = "panel1";
            panel1.Size = new Size(428, 571);
            panel1.TabIndex = 0;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.ForestGreen;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(45, 408);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(321, 84);
            btnLogin.TabIndex = 8;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // cmbUserType
            // 
            cmbUserType.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmbUserType.FormattingEnabled = true;
            cmbUserType.Items.AddRange(new object[] { "User", "Admin" });
            cmbUserType.Location = new Point(45, 324);
            cmbUserType.Name = "cmbUserType";
            cmbUserType.Size = new Size(321, 38);
            cmbUserType.TabIndex = 7;
            // 
            // txtPassword
            // 
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.Location = new Point(45, 236);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(321, 37);
            txtPassword.TabIndex = 6;
            // 
            // txtUsername
            // 
            txtUsername.BorderStyle = BorderStyle.FixedSingle;
            txtUsername.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUsername.Location = new Point(45, 136);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(321, 37);
            txtUsername.TabIndex = 5;
            // 
            // lblUserType
            // 
            lblUserType.AutoSize = true;
            lblUserType.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUserType.Location = new Point(39, 293);
            lblUserType.Name = "lblUserType";
            lblUserType.Size = new Size(97, 28);
            lblUserType.TabIndex = 4;
            lblUserType.Text = "User Type";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPassword.Location = new Point(39, 205);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(93, 28);
            lblPassword.TabIndex = 3;
            lblPassword.Text = "Password";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUsername.Location = new Point(39, 105);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(99, 28);
            lblUsername.TabIndex = 2;
            lblUsername.Text = "Username";
            // 
            // lblHeader
            // 
            lblHeader.AutoSize = true;
            lblHeader.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeader.Location = new Point(149, 33);
            lblHeader.Name = "lblHeader";
            lblHeader.Size = new Size(102, 38);
            lblHeader.TabIndex = 1;
            lblHeader.Text = "LOGIN";
            // 
            // pboxClose
            // 
            pboxClose.Image = (Image)resources.GetObject("pboxClose.Image");
            pboxClose.Location = new Point(479, 12);
            pboxClose.Name = "pboxClose";
            pboxClose.Size = new Size(32, 41);
            pboxClose.SizeMode = PictureBoxSizeMode.StretchImage;
            pboxClose.TabIndex = 9;
            pboxClose.TabStop = false;
            pboxClose.Click += pboxClose_Click;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(523, 665);
            Controls.Add(pboxClose);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmLogin";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pboxClose).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label lblHeader;
        private Button btnLogin;
        private ComboBox cmbUserType;
        private TextBox txtPassword;
        private TextBox txtUsername;
        private Label lblUserType;
        private Label lblPassword;
        private Label lblUsername;
        private PictureBox pboxClose;
    }
}