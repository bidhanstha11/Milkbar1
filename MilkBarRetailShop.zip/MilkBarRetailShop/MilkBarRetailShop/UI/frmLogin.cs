﻿using MilkBarRetailShop.BLL;
using MilkBarRetailShop.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MilkBarRetailShop.UI
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        loginBLL l = new loginBLL();
        loginDAL dal = new loginDAL();
        private void pboxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            l.username=txtUsername.Text.Trim();
            l.password=txtPassword.Text.Trim();
            l.user_type=cmbUserType.Text.Trim();

            bool success = dal.loginCheck(l);
            if (success)
            {
                MessageBox.Show("Login Successful");
                switch(l.user_type)
                {
                    case "Admin":
                        {
                            adminDashboard admin = new adminDashboard();
                            admin.Show();
                            this.Hide();
                        }
                        break;

                    case "User":
                        {
                            frmUserDashboard user = new frmUserDashboard();
                            user.Show();
                            this.Hide();    
                        }
                        break;

                    default:
                        {
                            MessageBox.Show("Invalid User Type.")
                        }
                        break ;
                }
            }
            else
            {
                MessageBox.Show("Login Failed");
            }
        }
    }
}
