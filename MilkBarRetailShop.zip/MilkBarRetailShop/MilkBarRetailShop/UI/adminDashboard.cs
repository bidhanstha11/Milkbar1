using MilkBarRetailShop.UI;

namespace MilkBarRetailShop
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
           frmUsers user = new frmUsers();
            user.Show();
        }

    }
}
