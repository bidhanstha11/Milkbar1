﻿namespace MilkBarRetailShop
{
    partial class AdminDashboard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlFooter = new Panel();
            lblFooter = new Label();
            menuStripTop = new MenuStrip();
            usersToolStripMenuItem = new ToolStripMenuItem();
            categoryToolStripMenuItem = new ToolStripMenuItem();
            productsToolStripMenuItem = new ToolStripMenuItem();
            inventoryToolStripMenuItem = new ToolStripMenuItem();
            transcationsToolStripMenuItem = new ToolStripMenuItem();
            lblUser = new Label();
            lblLoggedInUser = new Label();
            lblAppFName = new Label();
            lblLName = new Label();
            lblSHead = new Label();
            pnlFooter.SuspendLayout();
            menuStripTop.SuspendLayout();
            SuspendLayout();
            // 
            // pnlFooter
            // 
            pnlFooter.BackColor = Color.Teal;
            pnlFooter.Controls.Add(lblFooter);
            pnlFooter.Dock = DockStyle.Bottom;
            pnlFooter.Location = new Point(0, 523);
            pnlFooter.Name = "pnlFooter";
            pnlFooter.Size = new Size(1877, 150);
            pnlFooter.TabIndex = 0;
            // 
            // lblFooter
            // 
            lblFooter.AutoSize = true;
            lblFooter.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFooter.ForeColor = Color.White;
            lblFooter.Location = new Point(1077, 62);
            lblFooter.Name = "lblFooter";
            lblFooter.Size = new Size(210, 28);
            lblFooter.TabIndex = 0;
            lblFooter.Text = "Developed By Group 2";
            // 
            // menuStripTop
            // 
            menuStripTop.ImageScalingSize = new Size(24, 24);
            menuStripTop.Items.AddRange(new ToolStripItem[] { usersToolStripMenuItem, categoryToolStripMenuItem, productsToolStripMenuItem, inventoryToolStripMenuItem, transcationsToolStripMenuItem });
            menuStripTop.Location = new Point(0, 0);
            menuStripTop.Name = "menuStripTop";
            menuStripTop.Size = new Size(1877, 33);
            menuStripTop.TabIndex = 1;
            menuStripTop.Text = "menuStrip1";
            // 
            // usersToolStripMenuItem
            // 
            usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            usersToolStripMenuItem.Size = new Size(71, 29);
            usersToolStripMenuItem.Text = "Users";
            usersToolStripMenuItem.Click += new EventHandler(this.usersToolStripMenuItem_Click);


            // 
            // categoryToolStripMenuItem
            // 
            categoryToolStripMenuItem.Name = "categoryToolStripMenuItem";
            categoryToolStripMenuItem.Size = new Size(100, 29);
            categoryToolStripMenuItem.Text = "Category";
            // 
            // productsToolStripMenuItem
            // 
            productsToolStripMenuItem.Name = "productsToolStripMenuItem";
            productsToolStripMenuItem.Size = new Size(98, 29);
            productsToolStripMenuItem.Text = "Products";
            // 
            // inventoryToolStripMenuItem
            // 
            inventoryToolStripMenuItem.Name = "inventoryToolStripMenuItem";
            inventoryToolStripMenuItem.Size = new Size(103, 29);
            inventoryToolStripMenuItem.Text = "Inventory";
            // 
            // transcationsToolStripMenuItem
            // 
            transcationsToolStripMenuItem.Name = "transcationsToolStripMenuItem";
            transcationsToolStripMenuItem.Size = new Size(124, 29);
            transcationsToolStripMenuItem.Text = "Transcations";
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUser.Location = new Point(13, 45);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(55, 28);
            lblUser.TabIndex = 2;
            lblUser.Text = "User:";
            // 
            // lblLoggedInUser
            // 
            lblLoggedInUser.AutoSize = true;
            lblLoggedInUser.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLoggedInUser.ForeColor = Color.Lime;
            lblLoggedInUser.Location = new Point(74, 45);
            lblLoggedInUser.Name = "lblLoggedInUser";
            lblLoggedInUser.Size = new Size(166, 28);
            lblLoggedInUser.TabIndex = 3;
            lblLoggedInUser.Text = "Bidhan Shrestha";
            // 
            // lblAppFName
            // 
            lblAppFName.AutoSize = true;
            lblAppFName.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAppFName.Location = new Point(1095, 387);
            lblAppFName.Name = "lblAppFName";
            lblAppFName.Size = new Size(156, 54);
            lblAppFName.TabIndex = 4;
            lblAppFName.Text = "MilkBar";
            // 
            // lblLName
            // 
            lblLName.AutoSize = true;
            lblLName.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLName.Location = new Point(1239, 387);
            lblLName.Name = "lblLName";
            lblLName.Size = new Size(130, 54);
            lblLName.TabIndex = 5;
            lblLName.Text = "Retail";
            // 
            // lblSHead
            // 
            lblSHead.AutoSize = true;
            lblSHead.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSHead.ForeColor = Color.MediumSeaGreen;
            lblSHead.Location = new Point(1031, 441);
            lblSHead.Name = "lblSHead";
            lblSHead.Size = new Size(458, 38);
            lblSHead.TabIndex = 6;
            lblSHead.Text = "Billing and Inventory Management";
            // 
            // AdminDashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1877, 673);
            Controls.Add(lblSHead);
            Controls.Add(lblLName);
            Controls.Add(lblAppFName);
            Controls.Add(lblLoggedInUser);
            Controls.Add(lblUser);
            Controls.Add(pnlFooter);
            Controls.Add(menuStripTop);
            MainMenuStrip = menuStripTop;
            Name = "AdminDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin Dashboard";
            WindowState = FormWindowState.Maximized;
            pnlFooter.ResumeLayout(false);
            pnlFooter.PerformLayout();
            menuStripTop.ResumeLayout(false);
            menuStripTop.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlFooter;
        private Label lblFooter;
        private MenuStrip menuStripTop;
        private ToolStripMenuItem usersToolStripMenuItem;
        private ToolStripMenuItem categoryToolStripMenuItem;
        private ToolStripMenuItem productsToolStripMenuItem;
        private ToolStripMenuItem inventoryToolStripMenuItem;
        private ToolStripMenuItem transcationsToolStripMenuItem;
        private Label lblUser;
        private Label lblLoggedInUser;
        private Label lblAppFName;
        private Label lblLName;
        private Label lblSHead;
    }
}
