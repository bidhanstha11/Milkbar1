﻿
namespace MilkBarRetailShop.UI
{
    internal class adminDashboard
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}