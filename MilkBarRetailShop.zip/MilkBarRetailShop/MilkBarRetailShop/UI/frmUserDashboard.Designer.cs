﻿namespace MilkBarRetailShop
{
    partial class frmUserDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStripTop = new MenuStrip();
            purchaseToolStripMenuItem = new ToolStripMenuItem();
            salesFormsToolStripMenuItem = new ToolStripMenuItem();
            inventoryToolStripMenuItem = new ToolStripMenuItem();
            lblSHead = new Label();
            lblLName = new Label();
            lblAppFName = new Label();
            lblLoggedInUser = new Label();
            lblUser = new Label();
            pnlFooter = new Panel();
            lblFooter = new Label();
            menuStripTop.SuspendLayout();
            pnlFooter.SuspendLayout();
            SuspendLayout();
            // 
            // menuStripTop
            // 
            menuStripTop.ImageScalingSize = new Size(24, 24);
            menuStripTop.Items.AddRange(new ToolStripItem[] { purchaseToolStripMenuItem, salesFormsToolStripMenuItem, inventoryToolStripMenuItem });
            menuStripTop.Location = new Point(0, 0);
            menuStripTop.Name = "menuStripTop";
            menuStripTop.Size = new Size(1842, 33);
            menuStripTop.TabIndex = 0;
            menuStripTop.Text = "menuStrip1";
            // 
            // purchaseToolStripMenuItem
            // 
            purchaseToolStripMenuItem.Name = "purchaseToolStripMenuItem";
            purchaseToolStripMenuItem.Size = new Size(98, 29);
            purchaseToolStripMenuItem.Text = "Purchase";
            // 
            // salesFormsToolStripMenuItem
            // 
            salesFormsToolStripMenuItem.Name = "salesFormsToolStripMenuItem";
            salesFormsToolStripMenuItem.Size = new Size(68, 29);
            salesFormsToolStripMenuItem.Text = "Sales";
            // 
            // inventoryToolStripMenuItem
            // 
            inventoryToolStripMenuItem.Name = "inventoryToolStripMenuItem";
            inventoryToolStripMenuItem.Size = new Size(103, 29);
            inventoryToolStripMenuItem.Text = "Inventory";
            // 
            // lblSHead
            // 
            lblSHead.AutoSize = true;
            lblSHead.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSHead.ForeColor = Color.MediumSeaGreen;
            lblSHead.Location = new Point(1033, 450);
            lblSHead.Name = "lblSHead";
            lblSHead.Size = new Size(458, 38);
            lblSHead.TabIndex = 11;
            lblSHead.Text = "Billing and Inventory Management";
            // 
            // lblLName
            // 
            lblLName.AutoSize = true;
            lblLName.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLName.Location = new Point(1265, 396);
            lblLName.Name = "lblLName";
            lblLName.Size = new Size(130, 54);
            lblLName.TabIndex = 10;
            lblLName.Text = "Retail";
            // 
            // lblAppFName
            // 
            lblAppFName.AutoSize = true;
            lblAppFName.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAppFName.Location = new Point(1121, 396);
            lblAppFName.Name = "lblAppFName";
            lblAppFName.Size = new Size(156, 54);
            lblAppFName.TabIndex = 9;
            lblAppFName.Text = "MilkBar";
            // 
            // lblLoggedInUser
            // 
            lblLoggedInUser.AutoSize = true;
            lblLoggedInUser.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLoggedInUser.ForeColor = Color.Lime;
            lblLoggedInUser.Location = new Point(76, 54);
            lblLoggedInUser.Name = "lblLoggedInUser";
            lblLoggedInUser.Size = new Size(166, 28);
            lblLoggedInUser.TabIndex = 8;
            lblLoggedInUser.Text = "Bidhan Shrestha";
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUser.Location = new Point(15, 54);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(55, 28);
            lblUser.TabIndex = 7;
            lblUser.Text = "User:";
            // 
            // pnlFooter
            // 
            pnlFooter.BackColor = Color.Teal;
            pnlFooter.Controls.Add(lblFooter);
            pnlFooter.Dock = DockStyle.Bottom;
            pnlFooter.Location = new Point(0, 554);
            pnlFooter.Name = "pnlFooter";
            pnlFooter.Size = new Size(1842, 150);
            pnlFooter.TabIndex = 12;
            // 
            // lblFooter
            // 
            lblFooter.AutoSize = true;
            lblFooter.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFooter.ForeColor = Color.White;
            lblFooter.Location = new Point(1077, 62);
            lblFooter.Name = "lblFooter";
            lblFooter.Size = new Size(210, 28);
            lblFooter.TabIndex = 0;
            lblFooter.Text = "Developed By Group 2";
            // 
            // frmUserDashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1842, 704);
            Controls.Add(pnlFooter);
            Controls.Add(lblSHead);
            Controls.Add(lblLName);
            Controls.Add(lblAppFName);
            Controls.Add(lblLoggedInUser);
            Controls.Add(lblUser);
            Controls.Add(menuStripTop);
            MainMenuStrip = menuStripTop;
            Name = "frmUserDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "User Dashboard";
            WindowState = FormWindowState.Maximized;
            menuStripTop.ResumeLayout(false);
            menuStripTop.PerformLayout();
            pnlFooter.ResumeLayout(false);
            pnlFooter.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStripTop;
        private ToolStripMenuItem purchaseToolStripMenuItem;
        private ToolStripMenuItem salesFormsToolStripMenuItem;
        private ToolStripMenuItem inventoryToolStripMenuItem;
        private Label lblSHead;
        private Label lblLName;
        private Label lblAppFName;
        private Label lblLoggedInUser;
        private Label lblUser;
        private Panel pnlFooter;
        private Label lblFooter;
    }
}